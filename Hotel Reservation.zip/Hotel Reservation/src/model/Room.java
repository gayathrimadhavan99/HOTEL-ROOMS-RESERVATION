package model;

public  class Room implements IRoom {
    private String roomNumber;
    private Double roomPrice;
    private RoomType roomType;
    private Boolean isFree;

    public Room(String roomNumber,Double roomPrice,RoomType roomType,Boolean isFree)  {
        super();
        this.roomNumber= roomNumber;
        this.roomPrice=roomPrice;
        this.roomType=roomType;
        this.isFree=isFree;
    }

    public Room(String roomNumber, RoomType roomType) {
    }

    public Room(String roomNumber, double roomPrice, RoomType roomType) {
    }

    @Override
    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    @Override
    public Double getRoomPrice() {
        return roomPrice;
    }

    public void setRoomPrice(Double roomPrice) {
        this.roomPrice = roomPrice;
    }

    @Override
    public RoomType getRoomType() {
        return roomType;
    }

    public void setRoomType(RoomType roomType) {
        this.roomType = roomType;
    }

    @Override
    public boolean getBoolean() {
        return isFree;
    }

    @Override
    public void put(String roomNumber, IRoom room) {

    }

    public void setFree(Boolean free) {
        isFree = free;
    }

    @Override
     public String toString() {
        return super.toString() + "roomNumber:" + roomNumber + "roomPrice:" + roomPrice + "roomType:" + roomType + "Boolean:" + isFree;
    }
}







