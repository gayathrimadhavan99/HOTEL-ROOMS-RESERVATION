package Service;

import model.Customer;
import model.IRoom;
import model.Reservation;
import model.Room;

import java.util.*;

public class Collection {

    private static Customer Reservations;

    public static void main(String[] args) {

        List<String> getAllCustomers = new LinkedList<>();
        getAllCustomers.add("Aa");
        getAllCustomers.add("Bb");
        getAllCustomers.add("Cc");
        getAllCustomers.add("Dd");

       /* while (!getAllCustomers.isEmpty()) {
            System.out.println("Customer " + getAllCustomers.poll() + " is getting helped");
        }*/

        java.util.Collection<IRoom> getAllRoom = new LinkedList<IRoom>();
        getAllRoom.contains("");
        getAllRoom.contains("");
        getAllRoom.contains("");
        getAllRoom.contains("");

        java.util.Collection<IRoom> findRooms = new LinkedList<IRoom>();

        java.util.Collection<Reservation> getCustomersReservation = new LinkedList<Reservation>();
        getCustomersReservation.contains(Collections.singleton("" + ""));

    }

    public static java.util.Collection<Reservation> getAllReservations() {
        java.util.Collection<Reservation> allReservations = new LinkedList<>();

        for (Customer reservations : Reservations.values()) {
            allReservations.addAll((java.util.Collection<? extends Reservation>) reservations);
        }
        return getAllReservations();
    }
}


        /*List<Customer> getAllCustomers= new LinkedList<Customer>();

        for (Customer name : getAllCustomers) {
            System.out.println(name);
        }

        List<IRoom> getAllRoom= new LinkedList<IRoom>();
        for(IRoom room: getAllRoom) {
            System.out.println(room);
        }

        List<IRoom> findRooms= new LinkedList<IRoom>();

        if (IRoom = 0) {
            System.out.println("emptyroom");
        }
        else {
           System.out.println ("Room Reserved");
        }

        List<Reservation> getCustomersReservation= new LinkedList<Reservation>();



    }
}*/










