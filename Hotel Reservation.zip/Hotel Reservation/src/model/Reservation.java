package model;

import Service.ReservationService;

import java.util.Collection;
import java.util.Date;

public class Reservation{
    private  Customer customer;
    private  IRoom room;
    private Date checkInDate;
    private  Date checkOutDate;

    public Reservation(Customer customer,IRoom room, Date checkInDate,  Date checkOutDate) {
        //super();
        this.customer=customer;
        this.room=room;
        this.checkInDate=checkInDate;
        this.checkOutDate=checkOutDate;
    }

    public static void put(String email, Collection<Reservation> customerReservations) {
    }

    //public static Collection<Reservation> getCustomersReservation(Customer customer) {
      //  return getCustomersReservation(customer);
    //}

    //public static Collection<Reservation> getCustomersReservation(Customer customer) {
      //  return get;
    //}

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public void setRoom(IRoom room) {
        this.room = room;
    }
    public Date getCheckInDate() {
        return checkInDate;
    }

    public void setCheckInDate(Date checkInDate) {
        this.checkInDate = checkInDate;
    }

    public Date getCheckOutDate() {
        return checkOutDate;
    }

    public void setCheckOutDate(Date checkOutDate) {
        this.checkOutDate = checkOutDate;
    }
    public IRoom getRoom() {return this.room;}
    @Override
    public String toString() {
        return "Reservation{" +
                "customer=" + customer +
                ", room=" + room +
                ", checkInDate=" + checkInDate +
                ", checkOutDate=" + checkOutDate +
                '}';
    }


    public IRoom getARoom() {
        return null;
    }
}
