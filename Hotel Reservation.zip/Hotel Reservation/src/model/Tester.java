package model;

import Service.CustomerService;
import Service.ReservationService;
import api.AdminResource;
import api.HotelResource;

import java.util.Collection;
import java.util.Date;
import java.util.Scanner;

public class Tester {


    private static Date CheckInDate;
    private static Date CheckOutDate;

    public static void main(String[] args) {
        try {

            Customer customer = new Customer("Gayathri","M" , "j@domain.com");
            /*ReservationService addroom = new ReservationService();
            IRoom room;
            Reservation reserveARoom = new Reservation(customer,IRoom,CheckInDate,CheckOutDate);
            Reservation bookARoom = new Reservation("",room,1/8,7/8);*/
            System.out.println(customer);
            /*System.out.println(addroom );
            System.out.println(reserveARoom);
            System.out.println(bookARoom);*/



        }
        catch (IllegalArgumentException a){
           System.out.println(a.getLocalizedMessage());
        }
    }
}
