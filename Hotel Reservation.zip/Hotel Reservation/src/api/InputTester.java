/*package api;

import java.util.Scanner;

public class InputTester {
    public static void main(String[]args)
        Scanner scanner = new Scanner(System.in);
    try {

    }
}
*/