package api;

import Service.CustomerService;
import Service.ReservationService;
import model.Customer;
import model.IRoom;
import model.Reservation;

import java.util.Collection;
import java.util.List;

public class AdminResource {

    private static  AdminResource SINGLETON = new AdminResource();
    private  CustomerService customerService = CustomerService.getSingleton();
    private  ReservationService reservationService = ReservationService.getSingleton();

    public static Customer getCustomer(String email) {
        return getCustomer(email);
    }

    public static void addRoom(List<IRoom> rooms) {
    }

    public static Collection<IRoom> getAllRooms() {
        return getAllRooms();
    }

    public static Collection<Customer> getAllCustomers() {

        return CustomerService.getAllCustomers();
    }

    public static Collection<Reservation> getAllReservations() {
        return getAllReservations();
    }

    public static AdminResource getSingleton() {
        return SINGLETON;
    }

    public Collection<Reservation> display() {

        return (getAllReservations());
    }

    public void displayAllReservations() {
        ReservationService.printAllReservation();
    }
}




