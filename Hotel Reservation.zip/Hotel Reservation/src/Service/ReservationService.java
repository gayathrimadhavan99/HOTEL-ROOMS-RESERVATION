package Service;

import model.Customer;
import model.IRoom;
import model.Reservation;
import java.util.*;
import java.util.Collection;
import java.util.stream.Collectors;

public class ReservationService {

    private static  ReservationService SINGLETON = new ReservationService();
    private static  int RECOMMENDED_ROOMS_DEFAULT_PLUS_DAYS = 7;
    private static final Map<String, IRoom> rooms = new HashMap<>();
    private static Object Reservation;
    private final static Map<String, Collection<Reservation>> reservations = new HashMap<>();


    public static ReservationService getSingleton() {
        return SINGLETON;
    }
    public static void addRoom(IRoom room){
        room.put(room.getRoomNumber(), room);
    }
    public static  IRoom getARoom(String roomId){
        return getARoom("");
    }
    public static Collection<Object> getAllRooms() {
        HashMap<Object, Object> room = null;
        return room.values();
    }

    public static Reservation reserveARoom(Customer customer, IRoom room, Date CheckInDate, Date CheckOutDate){
         Reservation reservation = new Reservation(customer, room,  CheckInDate, CheckOutDate);

        Collection<Reservation> customerReservations = getCustomersReservation(customer);

        if (customerReservations == null) {
            customerReservations = new LinkedList<>();
        }

        customerReservations.add((Reservation) Reservation);
        reservation.put(customer.getEmail(), customerReservations);

        return reservation;
    }

    public static java.util.Collection<IRoom> findRooms(Date CheckInDate, Date CheckOutDate){
       return  findAvailableRooms(CheckInDate,CheckOutDate);
    }

    public static Collection<IRoom> findAlternativeRooms(Date CheckInDate, Date CheckOutDate) {
        return findAvailableRooms(addDefaultPlusDays(CheckInDate), addDefaultPlusDays(CheckOutDate));
    }

    private static Collection<IRoom> findAvailableRooms(Date CheckInDate, Date CheckOutDate) {
         Collection<Reservation> allReservations = getAllReservations();
         Collection<IRoom> notAvailableRooms = new LinkedList<>();

        for (Reservation reservation : allReservations) {
            if (reservationOverlaps(reservation, CheckInDate, CheckOutDate)) {
                notAvailableRooms.add(reservation.getARoom());
            }
        }

        return rooms.values().stream().filter(room -> notAvailableRooms.stream()
                .noneMatch(notAvailableRoom -> notAvailableRoom.equals(room)))
                .collect(Collectors.toList());
    }

    public static Date addDefaultPlusDays(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DATE, RECOMMENDED_ROOMS_DEFAULT_PLUS_DAYS);

        return calendar.getTime();
    }

    private static boolean reservationOverlaps(Reservation reservation, Date checkInDate,
                                               Date checkOutDate){
        return checkInDate.before(reservation.getCheckOutDate())
                && checkOutDate.after(reservation.getCheckInDate());
    }


    public static Collection<Reservation> getCustomersReservation(Customer customer){
        return reservations.get(customer.getEmail());
    }
    public static Collection<Reservation> getAllReservations() {
        final Collection<Reservation> allReservations = new LinkedList<>();
        for(Collection<Reservation> reservations : reservations.values()) {
            allReservations.addAll(reservations);
        }

        return allReservations;
    }

    public  static void printAllReservation() {
        Collection<Reservation> reservations = getAllReservations();

        if (reservations.isEmpty()) {
            System.out.println("No reservations found.");
        } else {
            for (Reservation reservation : reservations) {
                System.out.println(reservation + "\n");
            }
        }
    }

    }



