package model;

public class FreeRoom extends Room{
    private String roomNumber;
    private Double roomPrice;
    public FreeRoom(String roomNumber,Double roomPrice,RoomType roomType) {
        super(roomNumber,roomType);
        this.roomPrice= 0.0;
    }
    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public void setRoomPrice(Double roomPrice) {
        this.roomPrice = roomPrice;

    }
    @Override

    public String toString() {
        return super.toString() + "roomNumber:" + roomNumber + "roomPrice:" + roomPrice;
    }
}
