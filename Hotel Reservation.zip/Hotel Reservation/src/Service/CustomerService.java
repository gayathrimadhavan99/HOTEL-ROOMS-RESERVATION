package Service;

import model.Customer;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class CustomerService {

    private static  CustomerService SINGLETON = new CustomerService();

    private static   Map<String, Customer>  customers = new HashMap<>();

    public  static CustomerService getSingleton() {
        return SINGLETON;
    }
    public  static void addCustomer(String email,String firstname,String lastname) {

        Customer.put(email,firstname,lastname);

    }
    public static Customer getCustomer(final String CustomerEmail) {

        return customers.get(CustomerEmail);
    }
    public static Collection<Customer> getAllCustomers() {
        return Customer.values();

    }
    

}
