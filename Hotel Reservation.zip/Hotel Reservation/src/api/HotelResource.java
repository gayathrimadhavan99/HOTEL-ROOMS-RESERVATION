package api;

import Service.CustomerService;
import Service.ReservationService;
import model.Customer;
import model.IRoom;
import model.Reservation;
import java.util.Collection;
import java.util.Date;

public class HotelResource {
    private static HotelResource SINGLETON = new HotelResource();

    private CustomerService customerService = CustomerService.getSingleton();
    private ReservationService reservationService = ReservationService.getSingleton();

    static HotelResource getSingleton() {

        return SINGLETON;
    }

    public static Customer getCustomer(String email) {

        return CustomerService.getCustomer(email);
    }

    public static void createACustomer(String email, String firstName, String lastName) {
        CustomerService.addCustomer(email, firstName, lastName);
    }

    public static IRoom getRoom(String roomNumber) {

        return ReservationService.getARoom(roomNumber);
    }

    public static Reservation bookARoom(String customerEmail, IRoom room, Date checkInDate, Date checkOutDate) {
        return ReservationService.reserveARoom(getCustomer(customerEmail), room, checkInDate, checkOutDate);
    }

    public Collection<Reservation> getCustomersReservations(String CustomerEmail) {
        return ReservationService.getCustomersReservation(getCustomer(CustomerEmail));
    }

    public  Collection<IRoom> findARoom(Date checkIN, Date checkOut) {
        return ReservationService.findRooms(checkIN, checkOut);
    }

    public  Collection<IRoom> findAlternativeRooms(Date checkIn, Date checkOut) {
        return ReservationService.findAlternativeRooms(checkIn, checkOut);
    }

    public static Date addDefaultPlusDays(Date date) {
        return ReservationService.addDefaultPlusDays(date);
    }

}
        


