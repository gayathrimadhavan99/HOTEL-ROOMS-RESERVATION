package model;

import java.util.Collection;
import java.util.regex.Pattern;

public class Customer {
    private String  FirstName;
    private String  LastName;
    private final String email;
    public Customer(final String FirstName,final String LastName,final String email) {
        this.FirstName=FirstName;
        this.LastName=LastName;
        this.email=email;
        String emailRegex = "^(.+)@(.+).(.+)$";
        Pattern pattern = Pattern.compile(emailRegex);
        if(!pattern.matcher(email).matches()) {
            throw new IllegalArgumentException("Invalid email");
        }
    }

    public static void put(final String email, final String firstname, final String lastname) {
    }

    public static Collection<Customer> values() {
        return values();
    }

    public final String getFirstName() {

        return FirstName;
    }

    public void  setFirstName(final String firstName) {

        FirstName = firstName;
    }

    public String getLastName() {

        return LastName;
    }

    public void setLastName(final String lastName) {

        LastName = lastName;
    }
    public String getEmail() {

        return email;
    }

    @Override
    public String toString() {
        return   "FirstName:" + FirstName + "LastName:" + LastName + "email" + email;
    }
}

